import { Component, OnInit , Input, ChangeDetectorRef, ViewChild, ElementRef, SimpleChanges} from '@angular/core';
import { PageDataService } from 'app/services/pagedata.service';
import { PropertyEventEmitterService } from 'app/services/property-event-emitter.service';


@Component({
  selector: 'app-stepperwizard',
  templateUrl: './stepperwizard.component.html',
  styleUrls: ['./stepperwizard.component.css']
})
export class StepperwizardComponent implements OnInit {


  @Input() model: { type: string, id: number, columns };
  someHeight;
  @Input() list: any[];
  @Input() properties: any;
  @ViewChild('divContainer') dragContainer: ElementRef;
  allowedTypesList = ['label','div'];
  dragStart() {
    this.dragContainer.nativeElement.style = "display: inline-block; border: 2px dashed #585858; width: 100px; height: 30px; background : #e6e6e6";
    //this.cd.detach();
  }

  dragEnd() {
    //this.cd.reattach();
  }
  
  showHiddenEle: boolean = true;
  constructor(private cd: ChangeDetectorRef, private _pageDataService: PageDataService, private _propertyEventEmitterService: PropertyEventEmitterService) { }
  ngOnInit() {
    let _self = this;    

    this.prepagePreviewClass();

    _self.model['ngStyle'] = _self.getStyle(_self.model['properties']);

    if (_self.model['properties'] && _self.model['properties']['elementContainerStyleClass']) {
      _self.model['elementContainerStyleClass'] = _self.splitArray(_self.model['properties']['elementContainerStyleClass']);
    }

    if (_self.model['properties'] && _self.model['properties']['styleClass']) {
      _self.model['styleClass'] = _self.splitArray(_self.model['properties']['styleClass']);
    }

    if (_self.model['properties'] && _self.model['properties']['labelStyleClass']) {
      _self.model['labelStyleClass'] = _self.splitArray(_self.model['properties']['labelStyleClass']);
    }

    if (_self.model['properties'] && _self.model['properties']['displayNameStyleClass']) {
      _self.model['displayNameStyleClass'] = _self.splitArray(_self.model['properties']['displayNameStyleClass']);
    }

    this._pageDataService.getHiddenElementStateObservable().subscribe(data => {
      _self.cd.markForCheck();
      if (data != 'defaultHidden') {
        _self.showHiddenEle = data;
      }
    });

    this._pageDataService.getNgStyleStateObservable().subscribe(data => {
      _self.cd.markForCheck();
      if (data != 'defaultNgStyle') {
        _self.model['ngStyle'] = _self.getStyle(_self.model['properties']);

        if (_self.model['properties'] && _self.model['properties']['elementContainerStyleClass']) {
          _self.model['elementContainerStyleClass'] = _self.splitArray(_self.model['properties']['elementContainerStyleClass']);
        }

        if (_self.model['properties'] && _self.model['properties']['styleClass']) {
          _self.model['styleClass'] = _self.splitArray(_self.model['properties']['styleClass']);
        }

        if (_self.model['properties'] && _self.model['properties']['labelStyleClass']) {
          _self.model['labelStyleClass'] = _self.splitArray(_self.model['properties']['labelStyleClass']);
        }

        if (_self.model['properties'] && _self.model['properties']['displayNameStyleClass']) {
          _self.model['displayNameStyleClass'] = _self.splitArray(_self.model['properties']['displayNameStyleClass']);
        }
      }
    });

    if (_self.model['lgcolumn'] == undefined || _self.model['lgcolumn'] == '') {
      _self.model['lgcolumn'] = 4;
      _self.model['previewClass'] += " colLg4";
    }

    if (_self.model['mdcolumn'] == undefined || _self.model['mdcolumn'] == '') {
      _self.model['mdcolumn'] = 4;
      _self.model['previewClass'] += " colMd4";
    }

    if (_self.model['smcolumn'] == undefined || _self.model['smcolumn'] == '') {
      _self.model['smcolumn'] = 6;
      _self.model['previewClass'] += " colSm6";
    }

    if (_self.model['xscolumn'] == undefined || _self.model['xscolumn'] == '') {
      _self.model['xscolumn'] = 12;
      _self.model['previewClass'] += " colXs12";
    }
  }

  

  

  splitArray(array) {
    if (array != undefined && array.length > 0) {
      return array.toString().replace(/,/g, " ");
    }
  }

  public getStyle(styleObj) {
    let myStyles = {};

    if (styleObj['color']) {
      myStyles['color'] = styleObj['color'];
    }

    if (styleObj['background']) {
      myStyles['background-color'] = styleObj['background'];
    }

    if (styleObj['width']) {
      myStyles['width'] = styleObj['width'] + 'px';
    }

    if (styleObj['height']) {
      myStyles['height'] = styleObj['height'] + 'px';
    }

    if (styleObj['font-family']) {
      myStyles['font-family'] = styleObj['font-family'];
    }

    if (styleObj['font-size']) {
      myStyles['font-size'] = styleObj['font-size'] + 'px';
    }

    /* setting margin start */
    if (styleObj['margin-left']) {
      myStyles['margin-left'] = styleObj['margin-left'] + 'px';
    }

    if (styleObj['margin-top']) {
      myStyles['margin-top'] = styleObj['margin-top'] + 'px';
    }

    if (styleObj['margin-right']) {
      myStyles['margin-right'] = styleObj['margin-right'] + 'px';
    }

    if (styleObj['margin-bottom']) {
      myStyles['margin-bottom'] = styleObj['margin-bottom'] + 'px';
    }
    /* setting margin end */

    /* setting padding start */
    if (styleObj['padding-left']) {
      myStyles['padding-left'] = styleObj['padding-left'] + 'px';
    }

    if (styleObj['padding-top']) {
      myStyles['padding-top'] = styleObj['padding-top'] + 'px';
    }

    if (styleObj['padding-right']) {
      myStyles['padding-right'] = styleObj['padding-right'] + 'px';
    }

    if (styleObj['padding-bottom']) {
      myStyles['padding-bottom'] = styleObj['padding-bottom'] + 'px';
    }
    /* setting padding end */

    /* setting font style start */
    if (styleObj['font-weight']) {
      myStyles['font-weight'] = styleObj['font-weight'];
    }

    if (styleObj['font-style']) {
      myStyles['font-style'] = styleObj['font-style'];
    }

    if (styleObj['text-decoration']) {
      myStyles['text-decoration'] = styleObj['text-decoration'];
    }
    /* setting font style end */

    if (styleObj['text-align']) {
      myStyles['text-align'] = styleObj['text-align'];
    }

    if (styleObj['inlineStyle']) {
      var arr = styleObj['inlineStyle'].split(';').map(item => item.trim());
      arr.forEach(element => {
        var res = element.split(':').map(item => item.trim());
        if (res.length == 2) {
          myStyles[res[0]] = res[1];
        }
      });
    }

    return myStyles;
  }

  private prepagePreviewClass(): void {
    let _self = this;
    let arrClass = [];
    if ((_self.model['properties']['styleClass'] && _self.model['properties']['styleClass'].indexOf('col-') != -1) || (_self.model['properties']['elementContainerStyleClass'] && _self.model['properties']['elementContainerStyleClass'].indexOf('col-') != -1)) {

      if (_self.model['properties']['styleClass']) {
        if (_self.model['properties']['styleClass'].indexOf(',') != -1) {
          arrClass = _self.model['properties']['styleClass'].split(',');
        } else {
          arrClass = _self.model['properties']['styleClass'].split(' ');
        }
      } else if (_self.model['properties']['elementContainerStyleClass']) {
        if (_self.model['properties']['elementContainerStyleClass'].indexOf(',') != -1) {
          arrClass = _self.model['properties']['elementContainerStyleClass'].split(',');
        } else {
          arrClass = _self.model['properties']['elementContainerStyleClass'].split(' ');
        }
      }
    }

    _self.model['previewClass'] = '';
    if (arrClass.length > 0) {
      for (let x = 0; x < arrClass.length; x++) {
        if (arrClass[x].indexOf('col-') != -1) {
          if (arrClass[x].indexOf('col-lg-') != -1) {
            _self.model['lgcolumn'] = arrClass[x].split('-')[2];
            _self.model['previewClass'] += " colLg" + _self.model['lgcolumn'];
          } else if (arrClass[x].indexOf('col-md-') != -1) {
            _self.model['mdcolumn'] = arrClass[x].split('-')[2];
            _self.model['previewClass'] += " colMd" + _self.model['mdcolumn'];
          } else if (arrClass[x].indexOf('col-sm-') != -1) {
            _self.model['smcolumn'] = arrClass[x].split('-')[2];
            _self.model['previewClass'] += " colSm" + _self.model['smcolumn'];
          } else if (arrClass[x].indexOf('col-xs-') != -1) {
            _self.model['xscolumn'] = arrClass[x].split('-')[2];
            _self.model['previewClass'] += " colXs" + _self.model['xscolumn'];
          }
        }
      }
    } else {
      if (!_self._pageDataService.pages[_self._pageDataService.activeTabIdx]['map'] || !_self._pageDataService.pages[_self._pageDataService.activeTabIdx]['map']['APPLICATION'] || (_self._pageDataService.pages[_self._pageDataService.activeTabIdx]['map']['APPLICATION'] != "AOTS-vTM" || _self._pageDataService.pages[_self._pageDataService.activeTabIdx]['map']['APPLICATION'] != "vTM")) {
        if (!_self.model['lgcolumn']) {
          _self.model['lgcolumn'] = 4;
        }
        if (!_self.model['mdcolumn']) {
          _self.model['mdcolumn'] = 4;
        }
        if (!_self.model['smcolumn']) {
          _self.model['smcolumn'] = 6;
        }
        if (!_self.model['xscolumn']) {
          _self.model['xscolumn'] = 12;
        }
        if (!_self.model['elementContainerStyleClass'] || _self.model['elementContainerStyleClass'].indexOf('col-') != -1) {
          _self.model['elementContainerStyleClass'] += " col-lg-4 col-md-4 col-sm-6 col-xs-12";
        }
      }
    }
  }

  public removeItem(item: any, list: any[]): void {
    list.splice(list.indexOf(item), 1);
  }

  showProperties(model: any) {
    let objData = {
      item: model,
      operationType: 'showModel'
    }
   this._propertyEventEmitterService.changePropertyWindowState(objData);
  }

  deleteProperties(model: any) {
    let objData = {
      item: model,
      operationType: 'deleteModel'
    }

    this._propertyEventEmitterService.changePropertyWindowState(objData);
  }
}
