import { Component, OnInit, Input } from '@angular/core';
import { FormArray, FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  @Input() condLogicDropdownData;
  fCondLogic: FormGroup;
  selectedWhenSection: any;
  whenSectionAfterChangeEvent = [];
  showError: boolean = false;
  showSuccess: boolean = false;
  dataSaved: boolean = false;
  currentButton: any = 'first';

  constructor() {
  }

  ngOnInit() {
    this.fCondLogic = new FormGroup({
      condLogic: new FormArray([
        this.initcondLogic(),
      ]),
    });
  }

  resetForm() {
    this.fCondLogic = new FormGroup({
      condLogic: new FormArray([
        this.initcondLogic(),
      ]),
    });
  }

  compare(val1, val2) {
    return val1.name === val2.name;
  }

  saveCondLogic() {
    if (this.fCondLogic.invalid) {
      this.showError = true;
      this.showSuccess = false;
      this.dataSaved = false;
    } else {
      this.showError = false;
      this.showSuccess = true;
      this.dataSaved = true;
    }
  }

  changeWhenSection(name) {
    this.selectedWhenSection = this.condLogicDropdownData.find(i => i.name === name);
  }

  initcondLogic() {
    return new FormGroup({
      when: new FormArray([
        this.initWhen()
      ]),
      then: new FormArray([
        this.initThen()
      ])
    });
  }

  initWhen() {
    return new FormGroup({
      whenSection: new FormControl(''),
      whenElementName: new FormControl(''),
      whenOperator: new FormControl(''),
      whenValue: new FormControl(''),
      whenCase: new FormControl('')
    });
  }

  initThen() {
    return new FormGroup({
      thenAction: new FormControl('', Validators.required),
      thenSection: new FormControl('', Validators.required),
      thenElementName: new FormControl('')
    });
  }

  addcondLogic() {
    const control = <FormArray>this.fCondLogic.get('condLogic');
    control.push(this.initcondLogic());
  }

  addWhen(j) {
    const control = <FormArray>this.fCondLogic.get('condLogic')['controls'][j].get('when');
    control.push(this.initWhen());

  }

  addThen(j) {
    const control = <FormArray>this.fCondLogic.get('condLogic')['controls'][j].get('then');
    control.push(this.initThen());
  }

  getcondLogic(form) {
    return form.controls.condLogic.controls;
  }
  getWhen(form) {
    return form.controls.when.controls;
  }
  getThen(form) {
    return form.controls.then.controls;
  }

  removeWhen(i, j) {
    const control = <FormArray>this.fCondLogic.get(['condLogic', i, 'when']);
    control.removeAt(j);
  }

  removeThen(i, j) {
    const control = <FormArray>this.fCondLogic.get(['condLogic', i, 'then']);
    control.removeAt(j);
  }

  removecondLogic(i) {
    const control = <FormArray>this.fCondLogic.get('condLogic');
    control.removeAt(i);

  }

  whenSectionChanged(i, j) {
    const whenSectionType = this.fCondLogic.get('condLogic')['controls'][i].get('when')['controls'][j].get('whenSection').value;
    this.whenSectionAfterChangeEvent = this.condLogicDropdownData.filter(p => p.name == whenSectionType);
  }

}
